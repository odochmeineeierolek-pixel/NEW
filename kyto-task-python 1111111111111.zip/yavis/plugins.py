"""Plugin-Verwaltung: prüft und installiert .kyto/.zip-Pakete. Führt Plugins NICHT aus."""
import hashlib, json, re, shutil, zipfile
from pathlib import Path
from .config import home_dir
from .permissions import PermissionStore

REQUIRED = ("id", "name", "version", "description", "developer", "kyto_version", "entry", "permissions")
CRITICAL = {"trading", "wallet", "signing", "admin", "exec", "credentials"}
MAX_BYTES = 50 * 1024 * 1024

class PluginError(Exception):
    pass

def plugin_dir() -> Path:
    p = home_dir() / "plugins"; p.mkdir(parents=True, exist_ok=True); return p

def read_manifest(zf: zipfile.ZipFile) -> dict:
    for n in zf.namelist():
        if n.startswith("/") or ".." in Path(n).parts or ":" in n:
            raise PluginError(f"Unsicherer Pfad im Paket: {n}")
    if sum(i.file_size for i in zf.infolist()) > MAX_BYTES:
        raise PluginError("Paket ist zu groß (max. 50 MB)")
    if "manifest.json" not in zf.namelist():
        raise PluginError("manifest.json fehlt – das ist kein gültiges Kyto-Plugin")
    try: m = json.loads(zf.read("manifest.json").decode("utf-8"))
    except Exception: raise PluginError("manifest.json ist kein gültiges JSON")
    miss = [k for k in REQUIRED if k not in m]
    if miss: raise PluginError("Im Manifest fehlen: " + ", ".join(miss))
    if not re.fullmatch(r"[a-z0-9_.-]{3,64}", str(m["id"])): raise PluginError("Ungültige Plugin-ID")
    if not isinstance(m["permissions"], list): raise PluginError("permissions muss eine Liste sein")
    if m["entry"] not in zf.namelist(): raise PluginError("Einstiegspunkt fehlt im Paket: " + str(m["entry"]))
    if m.get("sha256") and hashlib.sha256(zf.read(m["entry"])).hexdigest() != str(m["sha256"]).lower():
        raise PluginError("Prüfsumme des Einstiegspunkts stimmt nicht – Paket verändert?")
    return m

class PluginManager:
    def __init__(self):
        self.state_file = home_dir() / "plugins.json"
        try: self.state = json.loads(self.state_file.read_text(encoding="utf-8"))
        except Exception: self.state = {}
    def _save(self): self.state_file.write_text(json.dumps(self.state, indent=1), encoding="utf-8")
    def inspect(self, path: str) -> dict:
        if Path(path).suffix.lower() not in (".kyto", ".zip"): raise PluginError("Nur .kyto oder .zip werden unterstützt")
        try:
            with zipfile.ZipFile(path) as zf: m = read_manifest(zf)
        except zipfile.BadZipFile: raise PluginError("Datei ist kein gültiges Paket")
        crit = sorted(set(map(str, m["permissions"])) & CRITICAL)
        signed = bool(m.get("signature"))
        d = PermissionStore().check("plugin-installer", "plugins.install", {"validated": True, "criticalPerms": bool(crit)})
        return dict(manifest=m, critical=crit, signed=signed, decision=d.decision, reason=d.reason)
    def install(self, path: str, confirmed: bool = False) -> dict:
        info = self.inspect(path)
        if info["decision"] == "deny": raise PluginError("Installation gesperrt: " + info["reason"])
        if info["decision"] == "ask" and not confirmed: raise PluginError("Bestätigung erforderlich: " + info["reason"])
        m = info["manifest"]; dest = plugin_dir() / m["id"]
        if dest.exists(): shutil.rmtree(dest)
        with zipfile.ZipFile(path) as zf: zf.extractall(dest)
        self.state[m["id"]] = dict(enabled=False, version=m["version"], name=m["name"], signed=info["signed"], permissions=m["permissions"])
        self._save(); return info
    def set_enabled(self, pid: str, on: bool):
        if pid in self.state: self.state[pid]["enabled"] = bool(on); self._save()
    def remove(self, pid: str):
        shutil.rmtree(plugin_dir() / pid, ignore_errors=True); self.state.pop(pid, None); self._save()
    def items(self): return dict(self.state)

"""Zusatzseiten: Sicherheit (Permission Center), System, Plugins."""
import time
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (QComboBox, QFileDialog, QFrame, QHBoxLayout, QInputDialog, QLabel, QLineEdit, QMessageBox,
                               QPlainTextEdit, QProgressBar, QPushButton, QScrollArea, QVBoxLayout, QWidget)
from .permissions import PermissionStore
from .pin import PinService
from .plugins import PluginManager, PluginError

def _lab(t, name=None, wrap=False):
    l = QLabel(t); l.setWordWrap(wrap)
    if name: l.setObjectName(name)
    return l

def _card():
    f = QFrame(); f.setObjectName("card"); v = QVBoxLayout(f); v.setContentsMargins(16, 14, 16, 14); return f, v

def _page(title, sub):
    w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(32, 28, 32, 24); v.setSpacing(12)
    v.addWidget(_lab(title, "h1")); v.addWidget(_lab(sub, "muted", True)); return w, v

NAMES = {"trading.live": "Echtes Trading", "mining": "Mining", "plugins.install": "Plugin-Installation", "files.approved": "Dateien in freigegebenen Ordnern", "programs.install": "Fehlende Programme installieren"}
MODES = [("allow", "Erlauben"), ("ask", "Immer fragen"), ("deny", "Sperren")]

def build_security_page(win):
    w, v = _page("Sicherheit", "Permission Center: Du entscheidest, was Kyto automatisch tun darf. Die PIN ist eine App-Sperre und ersetzt keine Windows-Kontosicherheit.")
    store = PermissionStore()
    log = QPlainTextEdit(); log.setReadOnly(True)
    def refresh():
        try: lines = open(store.log, encoding="utf-8").read().splitlines()[-100:]
        except Exception: lines = []
        log.setPlainText("\n".join(reversed(lines)))
    for action, (mode, rule) in [(a, (d["mode"], d["rule"])) for a, d in store.data.items()]:
        c, cv = _card(); row = QHBoxLayout()
        col = QVBoxLayout(); col.addWidget(_lab(NAMES.get(action, action), "sect")); col.addWidget(_lab("Regel: " + rule, "muted"))
        row.addLayout(col, 1); cb = QComboBox()
        for k, t in MODES: cb.addItem(t, k)
        cb.setCurrentIndex([k for k, _ in MODES].index(mode))
        def on_change(_i, a=action, box=cb):
            ok, err = store.set_mode(a, box.currentData(), "user")
            if not ok:
                QMessageBox.warning(win, "Nicht erlaubt", err)
                box.blockSignals(True); box.setCurrentIndex([k for k, _ in MODES].index(store.data[a]["mode"])); box.blockSignals(False)
            refresh()
        cb.currentIndexChanged.connect(on_change); row.addWidget(cb); cv.addLayout(row); v.addWidget(c)
    def change_pin():
        old, ok = QInputDialog.getText(win, "PIN ändern", "Aktuelle PIN:", QLineEdit.Password)
        if not ok: return
        new, ok = QInputDialog.getText(win, "PIN ändern", "Neue PIN (4–12 Ziffern):", QLineEdit.Password)
        if not ok: return
        good, err = PinService().change(old, new)
        QMessageBox.information(win, "PIN", "PIN geändert." if good else err)
    b = QPushButton("PIN ändern"); b.clicked.connect(change_pin); v.addWidget(b, 0, Qt.AlignLeft)
    v.addWidget(_lab("Protokoll", "sect")); v.addWidget(log, 1); refresh()
    t = QTimer(w); t.timeout.connect(refresh); t.start(4000)
    return w

def build_system_page(win):
    import psutil
    w, v = _page("System", "Auslastung deines PCs. Temperaturen werden nur angezeigt, wenn Windows sie bereitstellt.")
    rows = {}
    for key, title in (("cpu", "Prozessor"), ("ram", "Arbeitsspeicher")):
        c, cv = _card(); l = _lab(title, "sect"); bar = QProgressBar(); bar.setRange(0, 100); cv.addWidget(l); cv.addWidget(bar); v.addWidget(c); rows[key] = (l, bar)
    dc, dv = _card(); dv.addWidget(_lab("Laufwerke", "sect")); dl = _lab("", None, True); dv.addWidget(dl); v.addWidget(dc); v.addStretch(1)
    def tick():
        if not w.isVisible(): return
        cpu = psutil.cpu_percent(); m = psutil.virtual_memory()
        rows["cpu"][0].setText(f"Prozessor · {psutil.cpu_count()} Threads · {cpu:.0f} %"); rows["cpu"][1].setValue(int(cpu))
        rows["ram"][0].setText(f"Arbeitsspeicher · {m.used / 2**30:.1f} / {m.total / 2**30:.1f} GB"); rows["ram"][1].setValue(int(m.percent))
        out = []
        for p in psutil.disk_partitions():
            try: u = psutil.disk_usage(p.mountpoint); out.append(f"{p.device}  {u.free / 2**30:.0f} GB frei von {u.total / 2**30:.0f} GB")
            except Exception: pass
        dl.setText("\n".join(out) or "Keine Laufwerke lesbar")
    t = QTimer(w); t.timeout.connect(tick); t.start(2000); tick(); return w

def build_plugins_page(win):
    w, v = _page("Plugins", "Pakete (.kyto/.zip) werden geprüft und installiert, aber nie automatisch ausgeführt. Neue Plugins sind zunächst deaktiviert. Ein Plugin-Runner ist noch nicht eingebaut.")
    pm = PluginManager(); box = QVBoxLayout(); holder = QWidget(); holder.setLayout(box)
    def render():
        while box.count():
            it = box.takeAt(0)
            if it.widget(): it.widget().deleteLater()
        if not pm.items(): box.addWidget(_lab("Noch keine Plugins installiert.", "muted"))
        for pid, d in pm.items().items():
            c, cv = _card(); r = QHBoxLayout()
            r.addWidget(_lab(f"{d['name']}  v{d['version']}  ·  {'signiert' if d['signed'] else 'unsigniert'}\nRechte: {', '.join(d['permissions']) or 'keine'}"), 1)
            tg = QPushButton("Deaktivieren" if d["enabled"] else "Aktivieren")
            tg.clicked.connect(lambda _=False, p=pid, on=not d["enabled"]: (pm.set_enabled(p, on), render()))
            rm = QPushButton("Entfernen"); rm.clicked.connect(lambda _=False, p=pid: (pm.remove(p), render()))
            r.addWidget(tg); r.addWidget(rm); cv.addLayout(r); box.addWidget(c)
    def do_import():
        path, _ = QFileDialog.getOpenFileName(win, "Plugin wählen", "", "Kyto-Plugin (*.kyto *.zip)")
        if not path: return
        try:
            info = pm.inspect(path); m = info["manifest"]; need = info["decision"] == "ask"
            text = f"{m['name']} v{m['version']} von {m['developer']}\nRechte: {', '.join(m['permissions']) or 'keine'}\n" + ("UNSIGNIERT\n" if not info["signed"] else "") + "\nInstallieren?"
            if info["decision"] == "deny": raise PluginError(info["reason"])
            if QMessageBox.question(win, "Plugin installieren", text) != QMessageBox.StandardButton.Yes: return
            pm.install(path, confirmed=True)
        except PluginError as e:
            QMessageBox.warning(win, "Installation nicht möglich", str(e))
        render()
    b = QPushButton("Plugin importieren …"); b.clicked.connect(do_import); v.addWidget(b, 0, Qt.AlignLeft)
    v.addWidget(holder); v.addStretch(1); render(); return w

# ---------------------------------------------------------------- Trading
import json as _json, threading, time as _time, urllib.request
from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QCheckBox, QDoubleSpinBox
from .trading import TradingEngine

class _Sig(QObject):
    price = Signal(object)
    text = Signal(str)

COINS = ["bitcoin", "ethereum", "solana", "litecoin", "ripple"]

def build_trading_page(win):
    w, v = _page("Trading", "Paper-Trading ist eine Simulation. Live-Aufträge werden immer einzeln bestätigt und gegen deine Limits geprüft. Eine Börsenanbindung ist noch nicht installiert: Live-Aufträge werden daher nach der Prüfung abgelehnt, nicht gesendet.")
    eng = TradingEngine(); sig = _Sig(w); state = {"price": 0.0, "ts": 0.0}
    c, cv = _card(); form = QHBoxLayout()
    mode = QComboBox(); mode.addItem("Paper (Simulation)", False); mode.addItem("Live", True)
    coin = QComboBox(); [coin.addItem(x) for x in COINS]
    side = QComboBox(); side.addItem("Kaufen", "buy"); side.addItem("Verkaufen", "sell")
    eur = QDoubleSpinBox(); eur.setRange(1, 1_000_000); eur.setValue(50); eur.setSuffix(" €")
    for x in (mode, coin, side, eur): form.addWidget(x)
    cv.addLayout(form); info = _lab("Noch kein Preis geladen.", "muted", True); cv.addWidget(info)
    row = QHBoxLayout(); bp = QPushButton("Preis laden"); bo = QPushButton("Order senden"); bo.setObjectName("send"); bo.setMinimumWidth(120); bo.setMaximumWidth(16777215)
    row.addWidget(bp); row.addWidget(bo); row.addStretch(1); cv.addLayout(row); v.addWidget(c)
    sc, sv = _card(); sv.addWidget(_lab("Limits & Sicherheit (werden im Backend erzwungen)", "sect")); lr = QHBoxLayout()
    spins = []
    for label, key in (("Max. pro Order", "max_order"), ("Max. pro Tag", "max_day"), ("Max. Tagesverlust", "max_loss")):
        lr.addWidget(_lab(label)); s = QDoubleSpinBox(); s.setRange(0, 1_000_000); s.setValue(eng.d["limits"][key]); s.setSuffix(" €"); lr.addWidget(s); spins.append(s)
    sv.addLayout(lr)
    def save_limits():
        eng.set_limits(*[s.value() for s in spins]); out.appendPlainText("Limits gespeichert.")
    live_cb = QCheckBox("Live-Trading aktivieren (standardmäßig aus)"); live_cb.setChecked(eng.d["live_enabled"]); live_cb.toggled.connect(eng.set_live)
    bl = QPushButton("Limits speichern"); bl.clicked.connect(save_limits)
    kill = QPushButton("NOT-AUS"); kill.setObjectName("stop")
    def toggle_kill():
        eng.kill_switch(not eng.d["kill"]); kill.setText("Not-Aus aufheben" if eng.d["kill"] else "NOT-AUS")
    kill.clicked.connect(toggle_kill); kill.setText("Not-Aus aufheben" if eng.d["kill"] else "NOT-AUS")
    br = QHBoxLayout(); br.addWidget(live_cb); br.addStretch(1); br.addWidget(bl); br.addWidget(kill); sv.addLayout(br); v.addWidget(sc)
    out = QPlainTextEdit(); out.setReadOnly(True); v.addWidget(_lab("Verlauf", "sect")); v.addWidget(out, 1)
    def paper_text():
        p = eng.d["paper"]; return f"Virtuelles Guthaben: {p['eur']:.2f} €   Bestände: " + (", ".join(f"{k} {q:.6f}" for k, q in p["holdings"].items() if q > 1e-9) or "keine")
    out.appendPlainText(paper_text())
    def fetch():
        def work():
            try:
                with urllib.request.urlopen(f"https://api.coingecko.com/api/v3/simple/price?ids={coin.currentText()}&vs_currencies=eur", timeout=8) as r:
                    sig.price.emit(_json.loads(r.read().decode())[coin.currentText()]["eur"])
            except Exception as ex: sig.text.emit(f"Preis konnte nicht geladen werden: {ex}")
        threading.Thread(target=work, daemon=True).start(); info.setText("Lade Preis von CoinGecko …")
    def got_price(p):
        state.update(price=float(p), ts=_time.time()); info.setText(f"{coin.currentText()}: {p:,.2f} € (Quelle: CoinGecko, {_time.strftime('%H:%M:%S')}). Preise älter als 60 s blockieren Live-Aufträge.")
    sig.price.connect(got_price); sig.text.connect(lambda t: info.setText(t))
    def send():
        if state["price"] <= 0: info.setText("Bitte zuerst den Preis laden."); return
        live = mode.currentData(); qty = eur.value() / state["price"]
        order = dict(live=live, exchange="nicht verbunden", symbol=coin.currentText(), side=side.currentData(), qty=qty, price=state["price"], price_ts=state["ts"])
        ev = eng.evaluate(**order); confirmed = False
        if ev["decision"] == "ask":
            text = (f"Börse: {order['exchange']}\nInstrument: {order['symbol']}\nRichtung: {'Kauf' if order['side']=='buy' else 'Verkauf'}\n"
                    f"Menge: {qty:.8f}\nWert: {ev['notional']:.2f} €\nGebühr (geschätzt): {ev['fee']:.2f} €\nGesamt: {ev['total']:.2f} €\n\nDiesen einen Auftrag bestätigen?")
            confirmed = QMessageBox.question(win, "Live-Auftrag bestätigen", text) == QMessageBox.StandardButton.Yes
        ok, msg = eng.submit(order, confirmed); out.appendPlainText(("✔ " if ok else "✖ ") + msg); out.appendPlainText(paper_text())
    bp.clicked.connect(fetch); bo.clicked.connect(send); return w

# ---------------------------------------------------------------- Setup
from . import setup_helper

def build_setup_page(win):
    w, v = _page("Setup", "Kyto erkennt fehlende Programme und installiert sie auf Wunsch über winget. Jede Installation wird einzeln bestätigt und protokolliert.")
    sig = _Sig(w); sig.text.connect(lambda t: QMessageBox.information(win, "Setup", t))
    def refresh():
        while box.count():
            it = box.takeAt(0)
            if it.widget(): it.widget().deleteLater()
        for p in setup_helper.PROGRAMS:
            c, cv = _card(); r = QHBoxLayout(); ok = setup_helper.is_installed(p)
            r.addWidget(_lab(f"{'✔' if ok else '✖'}  {p['name']}  ·  {'installiert' if ok else 'fehlt'}"), 1)
            if not ok:
                b = QPushButton("Installieren" if p["winget"] else "Anleitung"); b.clicked.connect(lambda _=False, pr=p: install(pr)); r.addWidget(b)
            cv.addLayout(r); box.addWidget(c)
        c, cv = _card(); r = QHBoxLayout(); r.addWidget(_lab("PeakMiner (Mining-Programm, offizieller Download mit SHA-256-Prüfung)"), 1)
        b = QPushButton("Installieren"); b.clicked.connect(miner); r.addWidget(b); cv.addLayout(r); box.addWidget(c)
    def install(p):
        if not p["winget"]:
            QMessageBox.information(win, "Setup", "Der NVIDIA-Treiber kommt vom Hersteller (nvidia.com). Kyto kann ihn nicht sicher automatisch installieren."); return
        if QMessageBox.question(win, "Installieren", f"{p['name']} jetzt über winget installieren?\nDas kann einige Minuten dauern.") != QMessageBox.StandardButton.Yes: return
        def work():
            try: sig.text.emit(setup_helper.install(p, True))
            except Exception as ex: sig.text.emit("Fehler: " + str(ex))
        threading.Thread(target=work, daemon=True).start()
    def miner():
        if QMessageBox.question(win, "PeakMiner", "Offiziellen PeakMiner herunterladen und Prüfsumme prüfen? Er wird nicht gestartet.") == QMessageBox.StandardButton.Yes:
            win._goto(9); win._mining_download_peakminer()
    box = QVBoxLayout(); holder = QWidget(); holder.setLayout(box); v.addWidget(holder)
    rf = QPushButton("Erneut prüfen"); rf.clicked.connect(refresh); v.addWidget(rf, 0, Qt.AlignLeft); v.addStretch(1); refresh(); return w

"""Erkennt fehlende Programme und installiert sie nach Bestätigung über winget (Windows-Paketmanager)."""
import os, shutil, subprocess
from pathlib import Path
from .permissions import PermissionStore

PROGRAMS = [
    dict(id="ollama", name="Ollama (lokale KI)", winget="Ollama.Ollama", exe="ollama", path=None),
    dict(id="lmstudio", name="LM Studio (lokale KI)", winget="ElementLabs.LMStudio", exe=None,
         path=str(Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "LM Studio" / "LM Studio.exe")),
    dict(id="nvidia", name="NVIDIA-Treiber (nvidia-smi)", winget=None, exe="nvidia-smi", path=None),
]

def is_installed(p) -> bool:
    return bool((p["exe"] and shutil.which(p["exe"])) or (p["path"] and Path(p["path"]).is_file()))

def install(p, confirmed: bool) -> str:
    d = PermissionStore().check("setup", "programs.install", {})
    if d.decision == "deny": raise PermissionError("Installation gesperrt: " + d.reason)
    if not confirmed: raise PermissionError("Bestätigung erforderlich")
    if not p["winget"]: raise RuntimeError("Dieses Programm kann nicht automatisch installiert werden (Hersteller-Treiber).")
    if not shutil.which("winget"): raise RuntimeError("winget wurde auf diesem PC nicht gefunden (Windows 10/11 App-Installer fehlt).")
    r = subprocess.run(["winget", "install", "--id", p["winget"], "-e", "--accept-package-agreements", "--accept-source-agreements"],
                       capture_output=True, text=True, timeout=1800, shell=False)
    PermissionStore().audit("setup", "install:" + p["id"], f"exit {r.returncode}")
    if r.returncode != 0: raise RuntimeError((r.stdout + r.stderr).strip()[-600:] or f"winget Fehlercode {r.returncode}")
    return "Installiert. Kyto muss eventuell neu gestartet werden."

"""Trading-Engine: Paper-Trading + Live-Gate. Alle Grenzen werden HIER erzwungen, nicht in der Oberfläche.
Es ist keine Börsenanbindung eingebaut: Live-Aufträge werden geprüft, bestätigt, protokolliert und dann
mangels Adapter abgelehnt. Ein Adapter kann per register_adapter() ergänzt werden."""
import json, time
from .config import home_dir
from .permissions import PermissionStore

STALE_SECONDS = 60
DEFAULT = {"live_enabled": False, "kill": False, "exchanges": [], "limits": {"max_order": 100.0, "max_day": 300.0, "max_loss": 50.0},
           "day": "", "day_volume": 0.0, "day_loss": 0.0, "paper": {"eur": 1000.0, "holdings": {}}, "orders": []}

class TradingEngine:
    def __init__(self):
        self.file = home_dir() / "trading.json"; self.adapters = {}; self.perms = PermissionStore()
        self.d = json.loads(json.dumps(DEFAULT))
        try:
            saved = json.loads(self.file.read_text(encoding="utf-8"))
            for k in self.d: self.d[k] = saved.get(k, self.d[k])
        except Exception: pass
        self._roll(); self._save()
    def _save(self): self.file.write_text(json.dumps(self.d, indent=1), encoding="utf-8")
    def _roll(self):
        today = time.strftime("%Y-%m-%d")
        if self.d["day"] != today: self.d.update(day=today, day_volume=0.0, day_loss=0.0)
    def register_adapter(self, name, adapter): self.adapters[name] = adapter
    # --- Einstellungen (nur durch den Benutzer, nie durch Plugins/KI) ---
    def set_limits(self, max_order, max_day, max_loss):
        if min(max_order, max_day, max_loss) < 0: raise ValueError("Limits müssen >= 0 sein")
        self.d["limits"] = dict(max_order=float(max_order), max_day=float(max_day), max_loss=float(max_loss)); self._save()
        self.perms.audit("user", "trading.limits", str(self.d["limits"]))
    def set_live(self, on): self.d["live_enabled"] = bool(on); self._save(); self.perms.audit("user", "trading.live_enabled", str(bool(on)))
    def approve_exchange(self, name, on):
        ex = set(self.d["exchanges"]); (ex.add if on else ex.discard)(name); self.d["exchanges"] = sorted(ex); self._save()
    def kill_switch(self, on=True): self.d["kill"] = bool(on); self._save(); self.perms.audit("user", "trading.kill", str(bool(on)))
    # --- Prüfung ---
    def evaluate(self, *, live, exchange, symbol, side, qty, price, price_ts, leverage=1, fee_rate=0.001, now=None):
        self._roll(); now = now or time.time(); notional = qty * price; fee = notional * fee_rate
        r = dict(notional=round(notional, 2), fee=round(fee, 2), total=round(notional + fee if side == "buy" else notional - fee, 2))
        def out(dec, why): r.update(decision=dec, reason=why); return r
        if self.d["kill"]: return out("deny", "Not-Aus ist aktiv")
        if side not in ("buy", "sell") or not (qty > 0) or not (price > 0): return out("deny", "Ungültige Order")
        if leverage != 1: return out("deny", "Hebel ist deaktiviert")
        if not live:
            p = self.d["paper"]
            if side == "buy" and r["total"] > p["eur"]: return out("deny", "Nicht genug virtuelles Guthaben")
            if side == "sell" and qty > p["holdings"].get(symbol, 0): return out("deny", "Nicht genug virtuelle Bestände")
            return out("allow", "Paper-Trading (Simulation)")
        if not self.d["live_enabled"]: return out("deny", "Live-Trading ist nicht aktiviert")
        if exchange not in self.d["exchanges"]: return out("deny", "Börse nicht freigegeben")
        L = self.d["limits"]
        limits_ok = notional <= L["max_order"] and self.d["day_volume"] + notional <= L["max_day"] and self.d["day_loss"] < L["max_loss"]
        d = self.perms.check("trading", "trading.live", dict(paper=False, dataFresh=(now - price_ts) <= STALE_SECONDS, limitsOk=limits_ok))
        return out(d.decision, d.reason)
    def submit(self, order, confirmed=False):
        ev = self.evaluate(**order); live = order["live"]
        rec = dict(ts=int(time.time()), live=live, symbol=order["symbol"], side=order["side"], qty=order["qty"], price=order["price"], exchange=order["exchange"])
        if ev["decision"] == "deny" or (ev["decision"] == "ask" and not confirmed):
            rec["result"] = "abgelehnt: " + (ev["reason"] if ev["decision"] == "deny" else "keine Bestätigung")
            self._log(rec); return False, rec["result"]
        if not live:
            p = self.d["paper"]; s = order["symbol"]
            if order["side"] == "buy": p["eur"] -= ev["total"]; p["holdings"][s] = p["holdings"].get(s, 0) + order["qty"]
            else: p["eur"] += ev["total"]; p["holdings"][s] = p["holdings"].get(s, 0) - order["qty"]
            rec["result"] = "Paper-Order ausgeführt (Simulation)"; self._log(rec); return True, rec["result"]
        ad = self.adapters.get(order["exchange"])
        if not ad: rec["result"] = "abgelehnt: keine Börsenanbindung installiert"; self._log(rec); return False, rec["result"]
        res = ad.place_order(order); self.d["day_volume"] += ev["notional"]; rec["result"] = "gesendet: " + str(res); self._log(rec)
        return True, rec["result"]
    def _log(self, rec):
        self.d["orders"] = (self.d["orders"] + [rec])[-200:]; self._save()
        self.perms.audit("trading", f"{'LIVE' if rec['live'] else 'PAPER'} {rec['side']} {rec['symbol']}", rec["result"])

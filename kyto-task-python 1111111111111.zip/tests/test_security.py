import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
os.environ["KYTO_HOME"] = tempfile.mkdtemp()
from yavis.pin import PinService
from yavis.permissions import PermissionStore, decide
p = PinService()
assert p.must_change and p.verify("6894") == "ok" and p.verify("0000") == "wrong"
assert p.change("6894", "6894")[0] is False and p.change("6894", "4711")[0] is True
assert PinService().verify("4711") == "ok" and not PinService().must_change
q = PinService()
for _ in range(5): r = q.verify("1")
assert r == "locked" and q.verify("4711") == "locked"
s = PermissionStore()
assert s.data["trading.live"]["mode"] == "ask" and s.data["mining"]["mode"] == "allow"
assert s.set_mode("trading.live", "allow")[0] is False and s.set_mode("mining", "deny", actor="plugin")[0] is False
assert decide("trading.live", "allow", {"dataFresh": True, "limitsOk": True}).decision == "ask"
assert decide("trading.live", "ask", {}).decision == "deny"
assert decide("files.approved", "allow", {"path": "C:/x", "approvedDirs": ["D:/k"]}).decision == "deny"
assert decide("plugins.install", "allow", {}).decision == "deny"
assert s.set_mode("mining", "deny")[0] and s.check("mining", "mining", {"approvedHardware": True, "tempOk": True}).decision == "deny"
print("Sicherheitstests bestanden")
from yavis.config import Settings
assert Settings().get("gibt_es_nicht", "std") == "std"
print("Settings.get mit Standardwert ok")
import json, zipfile, hashlib
from yavis.plugins import PluginManager, PluginError
def mk(name, manifest, extra=None):
    path = os.path.join(tempfile.mkdtemp(), name)
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("manifest.json", json.dumps(manifest)); z.writestr("main.py", "print(1)")
        for k, v in (extra or {}).items(): z.writestr(k, v)
    return path
base = dict(id="demo.plugin", name="Demo", version="1.0", description="x", developer="me", kyto_version="1", entry="main.py", permissions=[])
pm = PluginManager()
pm.install(mk("a.kyto", base)); assert pm.items()["demo.plugin"]["enabled"] is False
pm.set_enabled("demo.plugin", True); assert PluginManager().items()["demo.plugin"]["enabled"] is True
pm.remove("demo.plugin"); assert "demo.plugin" not in PluginManager().items()
crit = dict(base, permissions=["wallet"])
try: pm.install(mk("b.kyto", crit)); raise SystemExit("kritisch ohne Bestätigung installiert")
except PluginError: pass
pm.install(mk("b.kyto", crit), confirmed=True)
for bad in (dict(base, sha256="0" * 64), {k: v for k, v in base.items() if k != "id"}):
    try: pm.install(mk("c.zip", bad)); raise SystemExit("ungültiges Plugin akzeptiert")
    except PluginError: pass
try: pm.inspect(mk("d.kyto", base, {"../evil.txt": "x"})); raise SystemExit("Pfadtrick akzeptiert")
except PluginError: pass
PermissionStore().set_mode("plugins.install", "deny")
try: pm.install(mk("e.kyto", dict(base, id="other.plugin"))); raise SystemExit("gesperrt, aber installiert")
except PluginError: pass
print("Plugin-Tests bestanden")
from yavis.trading import TradingEngine
import time as _t
T = TradingEngine(); now = _t.time()
o = dict(live=False, exchange="x", symbol="bitcoin", side="buy", qty=0.001, price=50000.0, price_ts=now)
assert T.submit(o)[0] and abs(T.d["paper"]["eur"] - (1000 - 50 * 1.001)) < 0.01
assert T.evaluate(**dict(o, leverage=3))["decision"] == "deny"
live = dict(o, live=True, exchange="TestBörse")
assert T.evaluate(**live)["reason"] == "Live-Trading ist nicht aktiviert"
T.set_live(True); assert "nicht freigegeben" in T.evaluate(**live)["reason"]
T.approve_exchange("TestBörse", True)
assert T.evaluate(**live)["decision"] == "ask"
assert T.evaluate(**dict(live, price_ts=now - 500))["decision"] == "deny"
assert T.evaluate(**dict(live, qty=1.0))["decision"] == "deny"
assert T.submit(live, confirmed=False)[0] is False
ok, msg = T.submit(live, confirmed=True); assert ok is False and "Börsenanbindung" in msg
T.kill_switch(True); assert T.evaluate(**o)["decision"] == "deny"
T.kill_switch(False)
class Fake:
    def place_order(self, o): return "id1"
T.register_adapter("TestBörse", Fake()); assert T.submit(live, confirmed=True)[0] is True
print("Trading-Tests bestanden")
from yavis import setup_helper
assert not setup_helper.install.__defaults__ and True
try: setup_helper.install(setup_helper.PROGRAMS[0], False); raise SystemExit("ohne Bestätigung installiert")
except PermissionError: pass
print("Setup-Tests bestanden")
